/**
 * Definitions
 **/

'use strict';

var APP_LINK_MAP = {
  'ios': 'https://itunes.apple.com/cn/app/he-hua-qin-zi-jie-jue-ma-ma/id910080489?l=en&mt=8',
  'android': 'http://www.hehuababy.com/android'
};